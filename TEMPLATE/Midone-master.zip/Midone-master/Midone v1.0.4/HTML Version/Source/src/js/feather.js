import feather from 'feather-icons'

(function() { 
    "use strict";
        
    // Feather Icons
    feather.replace({
        'stroke-width': 1.5
    })
    window.feather = feather
})()